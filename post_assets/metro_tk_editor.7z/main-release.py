from drawing import render
from constants import DATA_DIR

for city_name in ["Tokyo","Barcelona","Hong Kong"]:
    print(city_name)
    for turning_radius in [100,200,400]:
        render("{}\\{}.mmf".format(DATA_DIR, city_name),
               "release\\{}_{}.png".format(city_name, turning_radius),
               turning_radius=turning_radius)


