from math import floor, ceil, atan2, pi, sqrt, cos, sin, tan

from colorsys import rgb_to_hsv, hsv_to_rgb
from PIL import Image, ImageDraw
import numpy as np
from sklearn.cluster import KMeans

from base_classes import MetroMap, Line, Station, Point
from util import convex_hull, minimal_spanning_tree,dist

class MetroDrawer:

    def __init__(self, line_width,
                       station_radius,
                       link_width,
                       group_radius,
                       group_spacing,
                       default_line_color,
                       bg_color,
                       transparent_color,
                       group_color,
                       scale
                 ):
        self.line_width = line_width
        self.station_radius = station_radius
        self.link_width = link_width
        self.group_radius = group_radius
        self.group_spacing = group_spacing
        self.default_line_color = default_line_color
        self.bg_color = bg_color
        self.transparent_color = transparent_color
        self.group_color = group_color
        self.scale = scale
    def draw_line_segment(self, image, points, color=None):
        if color is None: color = self.default_line_color
        draw = ImageDraw.Draw(image)
        draw.line([(self.scale*pt.x, self.scale*pt.y) for pt in points], fill=color, width=self.line_width)
        del draw

    def draw_stations(self, image, points, color=None, inside_out = False):
        if color is None: color = self.default_line_color
        bg_color = self.bg_color
        if inside_out:
            color, bg_color = bg_color, color

        draw = ImageDraw.Draw(image)
        for point in points:
            px, py = (self.scale*point.x, self.scale*point.y)
            rad = self.station_radius
            draw.ellipse((px-rad, py-rad, px+rad, py+rad), fill=bg_color, outline=color, width=self.line_width)
        del draw

    def draw_weak_group(self, image, weak_group):
        draw = ImageDraw.Draw(image)
        poly = convex_hull([(self.scale*station.x, self.scale*station.y) for station in weak_group])
        if len(poly) > 1:
            draw.polygon(poly, fill=self.group_color)
            cp = poly[-1]
            for np in poly:
                draw.line((cp, np), fill=self.group_color, width=2*self.group_radius)
                cp = np
        mxx = 0
        mnx = image.width
        mxy = 0
        mny = image.height
        for x, y in poly:
            mxx = max(x, mxx)
            mnx = min(mnx, x)
            mxy = max(y, mxy)
            mny = min(mny, y)
            draw.ellipse((x-self.group_radius, y-self.group_radius, x+self.group_radius, y+self.group_radius), fill=self.group_color)
        mnx = floor(mnx)
        mny = floor(mny)
        mxx = ceil(mxx)
        mxy = floor(mxy)
        "linees diag  (mnx,mny) a (mxx,mxy-(mxx-mnx)) A (mnx,mny+(mxx-mnx))a(mxx,mxy)"
        for x in range(mnx-self.group_radius, mxx+self.group_radius):
            for y in range(mny-self.group_radius, mxy+self.group_radius):
                if ((x+y)//self.group_spacing)%2 == 0:
                    draw.point((x, y), fill=self.transparent_color)
        del draw
        
    def draw_weak_group_as_link(self, image, weak_group):
        #new (hacky, not the original intention) version: draws links between faraway groups of stations
        #assumes only 2 groups

        draw = ImageDraw.Draw(image)
        
        points = np.array([(self.scale*station.x, self.scale*station.y) for station in weak_group])
        labels = KMeans(n_clusters=2).fit(points).labels_
        group0_idx = np.where(1-labels)[0]
        group1_idx = np.where(labels)[0]
        group0 = points[group0_idx]
        group1 = points[group1_idx]
        sq_distances = np.sum(np.square(group0[:,np.newaxis,:]-group1[np.newaxis,:,:]),axis=2)
        idx_pair = np.unravel_index(np.argmin(sq_distances, axis=None), sq_distances.shape)

        idx0 = group0_idx[idx_pair[0]]
        idx1 = group1_idx[idx_pair[1]]
        
        point0 = points[idx0]
        point1 = points[idx1]

        #for x,y in [point0, point1]:
        #    draw.ellipse((x-self.group_radius, y-self.group_radius, x+self.group_radius, y+self.group_radius), fill=self.group_color)
        #draw.line((*point0, *point1), fill=self.group_color, width=self.group_width))#*2) #not an accident
        draw.line((*point0, *point1), fill=(150,150,150), width=int(0.5*self.line_width))#*2) #not an accident
        del draw
    
    def draw_group(self, image, group, fill=False):
        draw = ImageDraw.Draw(image)
        poly=convex_hull([(self.scale*station.x,self.scale*station.y) for station in group])
        if len(poly)>1:
            if fill: draw.polygon(poly,fill=self.group_color)
            cp=poly[-1]
            for np in poly:
                draw.line((cp,np),fill=self.group_color,width=2*self.group_radius)
                cp=np
        for x,y in poly:
            draw.ellipse((x-self.group_radius,y-self.group_radius,x+self.group_radius,y+self.group_radius),fill=self.group_color)
        if not fill:
            FACTOR=0.75
            if len(poly)>1:
                draw.polygon(poly,fill=self.bg_color)
                cp=poly[-1]
                for np in poly:
                    draw.line((cp,np),fill=self.bg_color,width=int(2*FACTOR*self.group_radius))
                    cp=np
            for x,y in poly:
                draw.ellipse((int(x-FACTOR*self.group_radius),
                              int(y-FACTOR*self.group_radius),
                              int(x+FACTOR*self.group_radius),
                              int(y+FACTOR*self.group_radius)),fill=self.bg_color)
        del draw

    def draw_link(self, image, group):
        "implicitly relies on stations being pre-drawn close enough to not warrant padding the whitespace"
        t_group = [(self.scale*p.x,self.scale*p.y) for p in group]
        linked_pairs = minimal_spanning_tree(t_group,dist)

        draw = ImageDraw.Draw(image)
        for p1,p2 in linked_pairs:
            draw.line((*p1,*p2),fill=self.bg_color,width=self.link_width)
        del draw

    def draw_link_fancy(self, image, group, color=None, inside_out=False):
        if color is None: color = self.default_line_color
        bg_color = self.bg_color
        
        if inside_out:
            color, bg_color = bg_color, color

        t_group = [(self.scale*p.x,self.scale*p.y) for p in group]
        linked_pairs = minimal_spanning_tree(t_group,dist)

        draw = ImageDraw.Draw(image)
        for station in group:
            px, py = (self.scale*station.x, self.scale*station.y)
            rad = self.station_radius
            draw.ellipse((px-rad, py-rad, px+rad, py+rad), outline=color, width=self.line_width)
        for p1,p2 in linked_pairs:
            draw.line((*p1,*p2),fill=color,width=3*self.link_width)
        for station in group:
            px, py = (self.scale*station.x, self.scale*station.y)
            rad = self.station_radius
            draw.ellipse((px-rad+self.line_width,
                          py-rad+self.line_width,
                          px+rad-self.line_width,
                          py+rad-self.line_width),
                         fill=bg_color, width=0)
        for p1,p2 in linked_pairs:
            draw.line((*p1,*p2),fill=bg_color,width=self.link_width)
        del draw
    
class GraphicalMetroMap(MetroMap):
    """Metromap keeping track of its own drawing"""

    def __init__(self, dimensions):
        super(GraphicalMetroMap,self).__init__()

        self.width,self.height = dimensions
        self.drawer = MetroDrawer(3,5,3,10,5,(0,0,0,255),(255,255,255),(0,0,0,0),(180,180,180),1)
        """
        LINE_WIDTH = 3
        STATION_RADIUS = 5
        LINK_WIDTH = 3
        GROUP_RADIUS = 10
        GROUP_SPACING = 5
        DEFAULT_LINE_COLOR = (0,0,0,255)
        BG_COLOR = (255,255,255)
        TRANSPARENT_COLOR = (0,0,0,0)
        GROUP_COLOR = (180,180,180)
        SCALE = 1
        """

        self.redraw_all()

    def link(self,station_1,station_2):
        super().link(station_1,station_2)
        self.clear_links()
        self.draw_all_links()
    def _register_station(self,station,line,heading):
        super()._register_station(station,line,heading)
        if isinstance(station,Station):
            self.drawer.draw_stations(self.stations_im,[station])
        if len(line.stations)>1:
            if heading == Line.Heading.END:
                self.drawer.draw_line_segment(self.lines_im,[line.stations[-2],station])
            elif heading == Line.Heading.START:
                self.drawer.draw_line_segment(self.lines_im,[line.stations[1],station])
    def add_group(self,group):
        self.drawer.draw_group(self.groups_im,group)
        super().add_group(group)
    def add_weak_group(self,weak_group):
        self.drawer.draw_weak_group(self.weak_groups_im,weak_group)
        super().add_weak_group(weak_group)

    def remove_station(self,station):
        super().remove_station(station)
        self.redraw_all()

    def join_stations(self,station_1,station_2):
        super().join_stations(station_1,station_2)
        self.drawer.draw_line_segment(self.lines_im,[station_1,station_2])

    def draw_all_weak_groups(self):
        for weak_group in self.weak_groups:
            self.drawer.draw_weak_group(self.weak_groups_im,weak_group)
    def draw_all_groups(self):
        for group in self.groups:    
            self.drawer.draw_group(self.groups_im,group)
    def draw_all_lines(self):
        for line in self.lines:
            self.drawer.draw_line_segment(self.lines_im,line.stations,color=line.color)
    def draw_all_stations(self):
        self.drawer.draw_stations(self.stations_im,[s for s in self.stations if isinstance(s,Station)])
    def draw_all_links(self):
        for link in self.list_links():
            self.drawer.draw_link(self.links_im, link)
    def draw_all(self):
        self.draw_all_weak_groups()
        self.draw_all_groups()
        self.draw_all_lines()
        self.draw_all_stations()
        self.draw_all_links()

    "suposant que el gc ho fa tot"
    def clear_links(self):
        self.links_im = Image.new("RGBA",(self.width,self.height),(0,0,0,0))
    def clear_all(self):
        self.weak_groups_im = Image.new("RGBA",(self.width,self.height),(0,0,0,0))
        self.groups_im = Image.new("RGBA",(self.width,self.height),(0,0,0,0))
        self.lines_im = Image.new("RGBA",(self.width,self.height),(0,0,0,0))
        self.stations_im = Image.new("RGBA",(self.width,self.height),(0,0,0,0))
        self.clear_links()
    def redraw_all(self):
        self.clear_all()
        self.draw_all()

    def load(self, filename):
        super().load(filename)
        self.redraw_all()









def render(data_path, render_path, turning_radius=100):
    SIZE=10000
    MARGIN=0.05
    MIN_CURVE_DIST=0 # in pixels - these should depend on the actual angle of the curve, really
    MAX_CURVE_DIST=turning_radius

    drawer = MetroDrawer(30, 50, 25, 70, 40, (0, 0, 0, 255), (255, 255, 255), (255,255,255,255), (230,230,230,255), SIZE)
    metro_map = MetroMap()
    metro_map.load(data_path)

    """
    LINE_WIDTH = 30
    STATION_RADIUS = 50
    LINK_WIDTH = 25
    GROUP_RADIUS = 70
    GROUP_SPACING = 40
    DEFAULT_LINE_COLOR = (0,0,0,255)
    BG_COLOR = (255,255,255)
    TRANSPARENT_COLOR = (0,0,0,0)
    GROUP_COLOR = (230,230,230,255)
    SCALE = 1
    """

    mxx = -float("inf"); mnx = float("inf")
    mxy = -float("inf"); mny = float("inf")
    for station in metro_map.stations:
        mxx = max(mxx,station.x); mnx = min(mnx,station.x)
        mxy = max(mxy,station.y); mny = min(mny,station.y)
    dx=mxx-mnx; dy=mxy-mny; d=max(dx,dy)
    a = (1-2*MARGIN)/d
    bx = MARGIN - mnx*(1-2*MARGIN)/d + (1-min(1,dx/dy))*(1-2*MARGIN)/2
    by = MARGIN - mny*(1-2*MARGIN)/d + (1-min(1,dy/dx))*(1-2*MARGIN)/2

    transform = lambda x,y: (a*x+bx,a*y+by)
    for station in metro_map.stations:
        station.x,station.y = transform(*station.pos())

    im = Image.new("RGBA",(SIZE,SIZE),"white")

    line_data = []
    new_pos = {station:station for station in metro_map.stations}
    for line in metro_map.lines:
        c_linedata = []
        track_bends = [False]*len(line.stations)
        direction = [atan2(s2.y-s1.y,s2.x-s1.x) for s1,s2 in zip(line.stations,line.stations[1:]+[line.stations[0]])]
        c_linedata.append(direction)
        for i in range(-1 if line.is_loop else 1,len(line.stations)-1):
            if abs(direction[i]-direction[i-1])>2*pi/100 and line.stations[i] not in sum(list(metro_map.list_links()),[]):
                track_bends[i]=True
        spaces = [0]*len(line.stations)
        for i in range(-1 if line.is_loop else 1,len(line.stations)-1):
            if track_bends[i]:
                space_before = dist(line.stations[i].pos(),line.stations[i-1].pos())/(2 if track_bends[i-1] else 1)
                space_after = dist(line.stations[i].pos(),line.stations[i+1].pos())/(2 if track_bends[i+1] else 1)
                space = min(space_before,space_after)
                if space*SIZE<MIN_CURVE_DIST:
                    track_bends[i]=False
                else:
                    spaces[i] = min(space,MAX_CURVE_DIST/SIZE)
        c_linedata.append(track_bends)
        c_linedata.append(spaces)

        centers = [None]*len(line.stations)
        rads = [None]*len(line.stations)
        pre_angles = [None]*len(line.stations)
        aft_angles = [None]*len(line.stations)
        for i in range(-1 if line.is_loop else 1,len(line.stations)-1):
            if track_bends[i]:
                angle_before=(direction[i-1]-pi)%(2*pi)
                angle_after=direction[i]
                if angle_before>angle_after: angle_before,angle_after = angle_after,angle_before
                angle_d = (angle_before-angle_after)%(2*pi)
                if angle_d>pi:
                    obtuse=True
                    angle_mid = ((angle_before+angle_after)/2)%(2*pi)
                else:
                    obtuse=False
                    angle_mid = ((angle_before+angle_after)/2)%(2*pi)+pi

                rad = abs(spaces[i]*tan(angle_d/2))
                hypot = sqrt(spaces[i]*spaces[i]+rad*rad)
                rads[i] = rad

                dx,dy = cos(angle_mid)*hypot,sin(angle_mid)*hypot
                cx,cy = line.stations[i].pos()
                px,py = cx+dx,cy+dy
                centers[i] = (px,py)

                new_x,new_y = px-dx*rad/hypot,py-dy*rad/hypot
                new_pos[line.stations[i]] = Point(new_x,new_y)

                if obtuse: angle_before,angle_after = angle_after,angle_before
                r2d = 360/(2*pi)
                pre_angles[i]=angle_before*r2d+90
                aft_angles[i]=angle_after*r2d-90
        c_linedata.extend([centers,rads,pre_angles,aft_angles])
        line_data.append(c_linedata)

    for weak_group in metro_map.weak_groups:
        if not weak_group: continue #this should be fixed in the drawing interface... delete groups when empty
        drawer.draw_weak_group_as_link(im,[new_pos[station] for station in weak_group])
    for group in metro_map.groups:
        drawer.draw_group(im,[new_pos[station] for station in group])

    for line,(direction,track_bends,spaces,centers,rads,pre_angles,aft_angles) in zip(metro_map.lines,line_data):
        for i in range(0 if line.is_loop else 1, len(line.stations)):
            dx = line.stations[i].x-line.stations[i-1].x
            dy = line.stations[i].y-line.stations[i-1].y
            d = sqrt(dx*dx+dy*dy)
            dx/=d; dy/=d
            p1x = line.stations[i-1].x+spaces[i-1]*dx
            p1y = line.stations[i-1].y+spaces[i-1]*dy
            p2x = line.stations[i].x-spaces[i]*dx
            p2y = line.stations[i].y-spaces[i]*dy
            drawer.draw_line_segment(im,[Point(p1x,p1y),Point(p2x,p2y)],color=line.color)
        for i in range(-1 if line.is_loop else 1,len(line.stations)-1):
            if track_bends[i]:
                draw = ImageDraw.Draw(im)
                hw = drawer.line_width/2
                px,py = centers[i]
                rad = rads[i]
                draw.arc((SIZE*(px-rad)-hw,SIZE*(py-rad)-hw,SIZE*(px+rad)+hw,SIZE*(py+rad)+hw),
                         pre_angles[i],
                         aft_angles[i],
                         width=drawer.line_width,fill=line.color)
                del draw

    for line in metro_map.lines:
        drawer.draw_stations(im,[new_pos[station] for station in line.stations if isinstance(station,Station)],color=line.color,inside_out=True)
        first_station = next((station for station in line.stations if isinstance(station, Station)))
        last_station = next((station for station in reversed(line.stations) if isinstance(station, Station)))
        drawer.draw_stations(im,[new_pos[first_station]],color=line.color)
        drawer.draw_stations(im,[new_pos[last_station]],color=line.color)

    #older approaches
    """
    for link in metro_map.list_links():
        link_colors = np.asarray([metro_map.get_line(station).color for station in link])
        link_color = tuple(np.mean(link_colors,axis=0).astype(int))
        drawer.draw_stations(im,link,color=link_color)
        drawer.draw_link_fancy(im,link,color=link_color)
    """
    """
    for link in metro_map.list_links():
        link_colors = np.asarray([metro_map.get_line(station).color for station in link])
        link_color = tuple(np.mean(link_colors,axis=0).astype(int))

        #maximize saturation
        hsv = rgb_to_hsv(*link_color[:-1])
        link_color = tuple(map(int,hsv_to_rgb(hsv[0],0.5+hsv[1]/2.8,hsv[2])))
        if len(link)==2 or True:
            link_color = (100,100,100)
            link_color = (50,50,50)
            drawer.draw_stations(im,link,color=link_color, inside_out=True)
            drawer.draw_link_fancy(im,link,color=link_color, inside_out=True)
        else:
            link_color = (150,150,150)
            drawer.draw_stations(im,link,color=link_color)
            drawer.draw_link_fancy(im,link,color=link_color)
    """
    for link in metro_map.list_links():
        link_color = (50,50,50)
        drawer.draw_stations(im,link,color=link_color, inside_out=True)
        drawer.draw_link_fancy(im,link,color=link_color, inside_out=True)

    im.save(render_path)

    #TODO : draw direction indicators on links
            
