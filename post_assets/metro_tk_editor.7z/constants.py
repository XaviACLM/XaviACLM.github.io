import os

ICON_DIR = os.path.join(os.getcwd(),"icons")
ORIGINAL_MAP_DIR = os.path.join(os.getcwd(),"original_maps")
DATA_DIR = os.path.join(os.getcwd(),"data")
RENDER_DIR = os.path.join(os.getcwd(),"renders")

LIGHTEN_CONST = 5

KEY_ID = {"Q":81,
          "W":87,
          "E":69,
          "S":83,
          "D":68,
          "Z":90,
          "X":88,
          "C":67,
          "V":86,
          "B":66,
          "P":80,
          "A":65,
          "CTRL":16777249,
          "ESC":16777216,
          " ":32,
          }
ID_KEY = {a:b for b,a in KEY_ID.items()}