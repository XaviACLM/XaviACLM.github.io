from enum import Enum
from math import sqrt, atan2, sin, cos, pi
from itertools import permutations

from PyQt6.QtWidgets import QWidget, QLabel
from PyQt6.QtGui import QImage, QPixmap
from PyQt6.QtCore import Qt, QPoint
from PIL.ImageQt import ImageQt
from PIL import Image, ImageDraw
import numpy as np

from drawing import GraphicalMetroMap
from base_classes import ControlPoint, Station
from util import dist, IconPicker, lighten_image, unlighten_pixel

from constants import ICON_DIR, ORIGINAL_MAP_DIR, DATA_DIR, ID_KEY

ICON_SIZE=50

SNAPPING_DISTANCE = 20
GROUPING_DISTANCE = SNAPPING_DISTANCE
LINK_DISTANCE=7

SNAPPER_RAD = 15
class MetroDrawingCanvas(QWidget):

    class State(Enum):
        FREE = 0
        SIMPLE_CLICK = 1
        DRAGGING_LEFT = 2
        DRAGGING_RIGHT = 3

    def __init__(self, name):
        super(MetroDrawingCanvas, self).__init__()
        self.name = name

        self.bg_im = lighten_image(Image.open("{}\\{}.png".format(ORIGINAL_MAP_DIR,self.name)))

        max_width = 1*(1920-100)
        max_height = 1*1080
        width_factor = max_width/self.bg_im.width
        height_factor = max_height/self.bg_im.height
        factor = min(width_factor,height_factor)

        self.width = int(self.bg_im.width*factor)
        self.height = int(self.bg_im.height*factor)
        self.left = 10
        self.top = 10

        self.bg_im.thumbnail((self.width,self.height))

        self.initVars()
        self.initPickers()
        self.initGUI()

    def initGUI(self):

        self.setGeometry(self.left, self.top, self.width, self.height)

        self.bg_overlay = QLabel("",self)
        self.bg_overlay.setGeometry(0,0,self.width,self.height)
        self.update_background_overlay()
        self.bg_overlay.show()
        self.bg_overlay.setMouseTracking(True)
        
        self.setMinimumSize(self.width,self.height)
        self.setMouseTracking(True)

        def default_overlay_init(overlay):
            overlay.setGeometry(0, 0, self.width, self.height)
            overlay.show()
            overlay.setMouseTracking(True)

        self.weak_group_overlay = QLabel("",self)
        default_overlay_init(self.weak_group_overlay)
        self.update_weak_group_overlay()

        self.group_overlay = QLabel("",self)
        default_overlay_init(self.group_overlay)
        self.update_group_overlay()

        self.assist_overlay = QLabel("",self)
        default_overlay_init(self.assist_overlay)
        self.update_assist_overlay()

        self.new_line_overlay = QLabel("", self)
        default_overlay_init(self.new_line_overlay)

        self.line_overlay = QLabel("",self)
        default_overlay_init(self.line_overlay)
        self.update_line_overlay()

        self.station_overlay = QLabel("",self)
        default_overlay_init(self.station_overlay)
        self.update_station_overlay()

        self.link_overlay = QLabel("",self)
        default_overlay_init(self.link_overlay)
        self.update_link_overlay()

        self.snapper_overlay = QLabel("",self)
        self.snapper_overlay.setGeometry(0, 0, 2*SNAPPER_RAD, 2*SNAPPER_RAD)
        im = Image.new("RGBA", (2*SNAPPER_RAD, 2*SNAPPER_RAD), (0,0,0,0))
        draw = ImageDraw.Draw(im)
        draw.ellipse((0, 0, 2*SNAPPER_RAD, 2*SNAPPER_RAD), fill=(255, 0, 0, 100), width=0)
        del draw
        qt_im = ImageQt(im)
        self.snapper_overlay.setPixmap(QPixmap.fromImage(QImage(qt_im)))
        self.snapper_overlay.show()
        self.snapper_overlay.setMouseTracking(True)
        self.snapper_overlay.setHidden(True)

        self.delete_icon.raise_()
        self.save_icon.raise_()
        self.load_icon.raise_()
        self.new_group_type.icon.raise_()
        self.laying_mode.icon.raise_()
        self.laying_type.icon.raise_()
        self.linearity.icon.raise_()
        self.assist.icon.raise_()
        self.snapper_toggle.icon.raise_()

        self.show()

    def update_background_overlay(self):
        self.bg_qtim = ImageQt(self.bg_im)
        self.bg_overlay.setPixmap(QPixmap.fromImage(QImage(self.bg_qtim)))
    def update_station_overlay(self):
        qt_im = ImageQt(self.metro_map.stations_im)
        self.station_overlay.setPixmap(QPixmap.fromImage(QImage(qt_im)))
    def update_line_overlay(self):
        qt_im = ImageQt(self.metro_map.lines_im)
        self.line_overlay.setPixmap(QPixmap.fromImage(QImage(qt_im)))
    def update_group_overlay(self):
        qt_im = ImageQt(self.metro_map.groups_im)
        self.group_overlay.setPixmap(QPixmap.fromImage(QImage(qt_im)))
    def update_weak_group_overlay(self):
        qt_im = ImageQt(self.metro_map.weak_groups_im)
        self.weak_group_overlay.setPixmap(QPixmap.fromImage(QImage(qt_im)))
    def update_new_line_overlay(self):
        is_join, is_link, points = self.get_new_segment()
        im = Image.new("RGBA", (self.width, self.height), (0, 0, 0, 0))
        self.metro_map.drawer.draw_line_segment(im, [self.dragging_from] + points, color=(255, 0, 0, 255))
        self.metro_map.drawer.draw_stations(im, points, color=(255, 0, 0, 255))
        qt_im = ImageQt(im)
        self.new_line_overlay.setPixmap(QPixmap.fromImage(QImage(qt_im)))
    def update_assist_overlay(self):
        bn = sqrt(2)*max(self.width,self.height)
        if not self.assist():
            self.assist_overlay.setHidden(True)
            return
        self.assist_overlay.setHidden(False)
        px,py = self.focused_station.pos()
        im = Image.new("RGBA", (self.width, self.height), (0, 0, 0, 0))
        for angle in np.linspace(0,pi,num=self.linearity()//2,endpoint = False):
            dx,dy = cos(angle),sin(angle)
            self.metro_map.drawer.draw_line_segment(im,[ControlPoint(px+bn*dx,py+bn*dy),ControlPoint(px-bn*dx,py-bn*dy)],color=(255,0,0,255))
        qt_im = ImageQt(im)
        self.assist_overlay.setPixmap(QPixmap.fromImage(QImage(qt_im)))
    def update_link_overlay(self):
        qt_im = ImageQt(self.metro_map.links_im)
        self.link_overlay.setPixmap(QPixmap.fromImage(QImage(qt_im)))

    def initVars(self):

        self.state = MetroDrawingCanvas.State.FREE

        self.metro_map = GraphicalMetroMap((self.width,self.height))

        self.closest_station = None
        self.closest_station_distance = None

        self.focused_station = None

        self.current_group = set()

        self.ctrl_down = False

        self.laying_quantity = 1
        self.laying_distance = 10

        self.mouse_x = 0
        self.mouse_y = 0

    def initPickers(self):
        c=1
        #some of these could be enums eh
        self.new_group_type = IconPicker(self,0,self.height-(2+c)*ICON_SIZE,["Strong","Weak"],[\
            Image.open("{}\\grouptype_strong_a.png".format(ICON_DIR)),
            Image.open("{}\\grouptype_weak_a.png".format(ICON_DIR))])
        self.laying_mode = IconPicker(self,ICON_SIZE,self.height-(2+c)*ICON_SIZE,["Quantity","Distance"],[\
            Image.open("{}\\layingmode_quantity_s.png".format(ICON_DIR)),
            Image.open("{}\\layingmode_distance_s.png".format(ICON_DIR))])
        self.laying_type = IconPicker(self,2*ICON_SIZE,self.height-(2+c)*ICON_SIZE,["Stations","Tracks"],[\
            Image.open("{}\\layingtype_stations_d.png".format(ICON_DIR)),
            Image.open("{}\\layingtype_tracks_d.png".format(ICON_DIR))])
        self.linearity = IconPicker(self,0,self.height-(1+c)*ICON_SIZE,[None,8,12],[\
            Image.open("{}\\linearity_free_z.png".format(ICON_DIR)),
            Image.open("{}\\linearity_8_z.png".format(ICON_DIR)),
            Image.open("{}\\linearity_12_z.png".format(ICON_DIR))])
        self.assist = IconPicker(self,ICON_SIZE,self.height-(1+c)*ICON_SIZE,[False,True],[\
            Image.open("{}\\assist_no_x.png".format(ICON_DIR)),
            Image.open("{}\\assist_yes_x.png".format(ICON_DIR))])
        self.snapper_toggle = IconPicker(self,2*ICON_SIZE,self.height-(1+c)*ICON_SIZE,[True,False],[\
            Image.open("{}\\snapper_yes_c.png".format(ICON_DIR)),
            Image.open("{}\\snapper_no_c.png".format(ICON_DIR))])

        # might as well init the static icons too
        self.delete_icon = QLabel("",self)
        self.delete_icon.setGeometry(0,self.height-(3+c)*ICON_SIZE,ICON_SIZE,ICON_SIZE)
        qt_im = ImageQt("{}\\delete_q.png".format(ICON_DIR))
        self.delete_icon.setPixmap(QPixmap.fromImage(QImage(qt_im)))
        self.delete_icon.show()

        self.load_icon = QLabel("",self)
        self.load_icon.setGeometry(ICON_SIZE,self.height-(3+c)*ICON_SIZE,ICON_SIZE,ICON_SIZE)
        qt_im = ImageQt("{}\\load_w.png".format(ICON_DIR))
        self.load_icon.setPixmap(QPixmap.fromImage(QImage(qt_im)))
        self.load_icon.show()

        self.save_icon = QLabel("",self)
        self.save_icon.setGeometry(2*ICON_SIZE,self.height-(3+c)*ICON_SIZE,ICON_SIZE,ICON_SIZE)
        qt_im = ImageQt("{}\\save_e.png".format(ICON_DIR))
        self.save_icon.setPixmap(QPixmap.fromImage(QImage(qt_im)))
        self.save_icon.show()

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            if self.state == MetroDrawingCanvas.State.FREE:
                if self.closest_station is not None:
                    self.state = MetroDrawingCanvas.State.DRAGGING_LEFT
                    self.dragging_from = self.closest_station
                    self.new_line_overlay.setHidden(False)
                else:
                    self.state = MetroDrawingCanvas.State.SIMPLE_CLICK
                    self.metro_map.add_line(Station(self.mouse_x,self.mouse_y))
                    self.update_station_overlay()
                    self.update_closest_station()
            else:
                print("Unparsed mouseclick at MetroDrawingCanvas")
        elif event.button() == Qt.MouseButton.RightButton:
            if self.state == MetroDrawingCanvas.State.FREE:
                self.state = MetroDrawingCanvas.State.DRAGGING_RIGHT
                self.current_group = set()
            else:
                print("Unparsed mouseclick at MetroDrawingCanvas")
        else:
            print("Unrecognized mouseclick at MetroDrawingCanvas")

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            if self.state == MetroDrawingCanvas.State.SIMPLE_CLICK:
                self.state = MetroDrawingCanvas.State.FREE
            elif self.state == MetroDrawingCanvas.State.DRAGGING_LEFT:
                self.state = MetroDrawingCanvas.State.FREE
                self.new_line_overlay.setHidden(True)

                self.mouse_x,self.mouse_y = event.position().x(),event.position().y()

                is_join,is_link,points = self.get_new_segment()
                if is_link:
                    self.metro_map.add_line(*points)
                    self.metro_map.link(self.dragging_from,*points)
                    self.update_link_overlay()
                elif is_join:
                    extended_line = self.metro_map.get_line(self.dragging_from)
                    heading = extended_line.get_heading_of(self.dragging_from)
                    assert heading is not None
                    for station in points[:-1]:
                        extended_line.add_station(station,heading)
                    self.metro_map.join_stations(extended_line.get_terminal(heading),points[-1])
                else:
                    extended_line = self.metro_map.get_line(self.dragging_from)
                    heading = extended_line.get_heading_of(self.dragging_from)
                    assert heading is not None
                    for station in points:
                        extended_line.add_station(station,heading)
                self.update_station_overlay()
                self.update_line_overlay()
                self.update_closest_station()
            else:
                print("Unparsed mouserelease at MetroDrawingCanvas")
        elif event.button() == Qt.MouseButton.RightButton:
            if self.state == MetroDrawingCanvas.State.DRAGGING_RIGHT:
                self.state = MetroDrawingCanvas.State.FREE
                if len(self.current_group)<=1:
                    pass
                elif self.new_group_type()=="Strong":
                    self.metro_map.add_group(list(self.current_group))
                    self.update_group_overlay()
                elif self.new_group_type()=="Weak":
                    self.metro_map.add_weak_group(list(self.current_group))
                    self.update_weak_group_overlay()
            else:
                print("Unparsed mouserelease at MetroDrawingCanvas")
        else:
            print("Unrecognized mouserelease at MetroDrawingCanvas")
        
    def mouseMoveEvent(self, event):
        if self.state == MetroDrawingCanvas.State.FREE:
            self.mouse_x,self.mouse_y = event.position().x(),event.position().y()
            self.update_closest_station()
        elif self.state == MetroDrawingCanvas.State.SIMPLE_CLICK:
            pass
        elif self.state == MetroDrawingCanvas.State.DRAGGING_LEFT:
            self.mouse_x,self.mouse_y = event.position().x(),event.position().y()

            self.update_closest_station()

            self.update_new_line_overlay()

        elif self.state == MetroDrawingCanvas.State.DRAGGING_RIGHT:
            self.mouse_x,self.mouse_y = event.position().x(),event.position().y()
            self.update_closest_station()
            if self.closest_station is not None\
                    and self.closest_station_distance<=GROUPING_DISTANCE:
                self.current_group.add(self.closest_station)

    def wheelEvent(self, event):
        direction = (lambda x: (x > 0)-(x < 0))(event.angleDelta().y())
        if self.ctrl_down:
            print("Zooming isn't implemented")
        else:
            if self.laying_mode() == "Quantity":
                self.laying_quantity = max(1, self.laying_quantity+direction)
            elif self.laying_mode() == "Distance":
                self.laying_distance = max(1, self.laying_distance+direction)
            if self.state == MetroDrawingCanvas.State.DRAGGING_LEFT:
                self.update_new_line_overlay()

    def keyPressEvent(self, event):
        if event.key() in ID_KEY:
            key = ID_KEY[event.key()]
            if key=="A":
                self.new_group_type.next()
            elif key=="S":
                self.laying_mode.next()
                if self.state == MetroDrawingCanvas.State.DRAGGING_LEFT:
                    self.update_new_line_overlay()
            elif key=="D":
                self.laying_type.next()
                if self.state == MetroDrawingCanvas.State.DRAGGING_LEFT:
                    self.update_new_line_overlay()
            elif key=="Z":
                self.linearity.next()
                if self.state == MetroDrawingCanvas.State.DRAGGING_LEFT:
                    self.update_new_line_overlay()
                if self.linearity() is None and self.assist():
                    self.assist.next()
                    self.update_assist_overlay()
            elif key=="X":
                if not self.assist():
                    if self.closest_station is not None and self.linearity() is not None:
                        self.focused_station = self.closest_station
                        self.assist.next()
                        self.update_assist_overlay()
                else:
                    self.focused_station = None
                    self.assist.next()
                    self.update_assist_overlay()
            elif key=="C":
                self.snapper_toggle.next()
                self.update_closest_station()
            elif key=="Q":
                self.delete_event()
            elif key=="W":
                self.load()
            elif key=="E":
                self.save()
            elif key=="CTRL":
                self.ctrl_down = True
            elif key=="ESC":
                self.close()
            elif key=="P":
                self.pick_color()
            else:
                print("Unparsed keypress in MetroDrawingCanvas")
        else:
            print("Unrecognized keypress {} in MetroDrawingCanvas".format(event.key()))

    def keyReleaseEvent(self, event):
        if event.key() in ID_KEY:
            key = ID_KEY[event.key()]
            if key in ["Q","W","E","A","S","D","Z","X","C","P","ESC"]:
                pass
            elif key=="CTRL":
                self.ctrl_down = False
            else:
                print("Unparsed keyrelease in MetroDrawingCanvas")
        else:
            print("Unrecognized keyrelease {} in MetroDrawingCanvas".format(event.key()))

    def update_closest_station(self):
        # are there updatable nearest neighbour strategies?
        if not self.snapper_toggle():
            self.closest_station = None
            self.closest_station_distance = None
            return
        closest_station = None
        closest_distance = float("inf")
        for station in self.metro_map.stations:
            if isinstance(station,Station) or self.metro_map.get_line(station).has_terminal(station):
                distance = dist(station.pos(),(self.mouse_x,self.mouse_y))
                if distance<closest_distance:
                    closest_distance = distance
                    closest_station = station
        if closest_distance <= SNAPPING_DISTANCE:
            self.closest_station = closest_station
            self.closest_station_distance = closest_distance

            self.snapper_overlay.setHidden(False)
            #self.snapper_overlay.move(self.closest_station.x-SNAPPER_RAD,self.closest_station.y-SNAPPER_RAD)
            self.snapper_overlay.pos = QPoint(int(self.closest_station.x-SNAPPER_RAD),int(self.closest_station.y-SNAPPER_RAD))
        else:
            self.closest_station = None
            self.closest_station_distance = None

            # this makes the mouse tracking bug out, so...
            # self.snapper_overlay.setHidden(True)
            self.snapper_overlay.move(-SNAPPER_RAD * 3, -SNAPPER_RAD * 3)

    def get_new_segment(self):

        is_join = False
        is_link = False
        source_x, source_y = self.dragging_from.pos()
        target_x,target_y = self.mouse_x,self.mouse_y
        d = dist((source_x,source_y),(target_x,target_y))
        if d<=SNAPPING_DISTANCE or \
                not self.metro_map.get_line(self.dragging_from).has_terminal(self.dragging_from):
            is_link = True

            dx, dy = target_x - source_x, target_y - source_y
            d = sqrt(dx * dx + dy * dy)
            alpha = atan2(dy,dx)
            if self.linearity() is not None:
                alpha = ((alpha+2*pi/self.linearity()/2)//(2*pi/self.linearity()))*(2*pi/self.linearity())
            new_dx = LINK_DISTANCE*cos(alpha)
            new_dy = LINK_DISTANCE*sin(alpha)

            target_x = source_x+new_dx
            target_y = source_y+new_dy

            return is_join,is_link,[Station(target_x,target_y)]

        if self.closest_station is not None:
            target_x, target_y = self.closest_station.pos()
            is_join = True
        elif self.assist() and self.linearity() is not None:
            target_x,target_y = self.focused_station.pos()
            angles = np.linspace(0,pi,num=self.linearity()//2,endpoint = False)
            intersections = []
            for angle_source,angle_target in permutations(angles,r=2):
                dx0,dy0 = cos(angle_source),sin(angle_source)
                dx1,dy1 = cos(angle_target),sin(angle_target)
                dx = target_x-source_x
                dy = target_y-source_y
                det = dx0*dy1-dx1*dy0
                lambda_source = (dy1*dx-dx1*dy)/det
                # lambda_target = (-dy0*dx+dx0*dy)/det
                intersection_x = source_x+lambda_source*dx0
                intersection_y = source_y+lambda_source*dy0
                intersections.append((intersection_x,intersection_y))
            closest_intersection = None
            closest_distance = float("inf")
            for intersection in intersections:
                distance = dist((self.mouse_x,self.mouse_y),intersection)
                if distance < closest_distance:
                    closest_distance = distance
                    closest_intersection = intersection
            target_x, target_y = closest_intersection

        elif not self.assist() and self.linearity() is not None:
            dx, dy = target_x - source_x, target_y - source_y
            d = sqrt(dx * dx + dy * dy)
            alpha = atan2(dy,dx)
            if self.linearity() == 8:
                new_alpha = ((alpha+2*pi/8/2)//(2*pi/8))*(2*pi/8)
            elif self.linearity() == 12:
                new_alpha = ((alpha+2*pi/12/2)//(2*pi/12))*(2*pi/12)
            new_dx = d*cos(new_alpha)
            new_dy = d*sin(new_alpha)

            target_x = source_x+new_dx
            target_y = source_y+new_dy

        if self.laying_mode() == "Distance":
            dx, dy = target_x - source_x, target_y - source_y
            d = sqrt(dx * dx + dy * dy)
            # calms np down
            station_qt = int(d/self.laying_distance)
            factor = self.laying_distance*station_qt/d
            target_x = source_x+dx*factor
            target_y = source_y+dy*factor
        elif self.laying_mode() == "Quantity":
            station_qt = self.laying_quantity

        if self.laying_type() == "Tracks":
            if is_join:
                return is_join,is_link,[self.closest_station]
            else:
                return is_join, is_link, [ControlPoint(target_x,target_y)]
        elif self.laying_type() == "Stations":
            if is_join and self.laying_mode()=="Distance":
                positions = []
                for sx, sy in np.linspace([target_x, target_y], [source_x,source_y], num=station_qt,
                                          endpoint=False)[::-1]:
                    positions.append(Station(sx, sy))
                positions.append(self.closest_station)
                return is_join,is_link,positions
            else:
                positions = []
                for sx, sy in np.linspace([target_x, target_y], [source_x,source_y], num=station_qt,
                                          endpoint=False)[::-1]:
                    positions.append(Station(sx, sy))
                if is_join: positions[-1] = self.closest_station
                return is_join,is_link,positions

    def delete_event(self):
        if self.closest_station is not None:
            self.delete_station(self.closest_station)
        self.update_closest_station()

    def delete_station(self,station):
        self.metro_map.remove_station(station)
        self.update_group_overlay()
        self.update_line_overlay()
        self.update_link_overlay()
        self.update_station_overlay()
        self.update_weak_group_overlay()

    def save(self):
        self.metro_map.save("{}\\{}.mmf".format(DATA_DIR,self.name))

    def load(self):
        self.metro_map.load("{}\\{}.mmf".format(DATA_DIR,self.name))
        self.update_group_overlay()
        self.update_line_overlay()
        self.update_link_overlay()
        self.update_station_overlay()
        self.update_weak_group_overlay()

    def pick_color(self):
        if self.closest_station is not None:
            color = unlighten_pixel(self.bg_im.getpixel((self.mouse_x,self.mouse_y)))
            self.metro_map.get_line(self.closest_station).color = color
            self.update_line_overlay()
            print(color)
