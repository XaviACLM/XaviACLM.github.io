from functools import reduce
from itertools import combinations,cycle
from math import sqrt

from PyQt6.QtWidgets import QLabel
from PyQt6.QtGui import QImage, QPixmap
from PIL.ImageQt import ImageQt

import numpy as np
from PIL import Image
from constants import LIGHTEN_CONST

def unlighten_pixel(x):
    r,g,b,a = x
    r = 255-(255-r)*(LIGHTEN_CONST-1)
    g = 255-(255-g)*(LIGHTEN_CONST-1)
    b = 255-(255-b)*(LIGHTEN_CONST-1)
    return r,g,b,a

def lighten_image(im,factor=LIGHTEN_CONST):
    array=np.asarray(im.convert("RGBA")).copy()
    array[array[..., -1] == 0] = [255, 255, 255, 0]
    return Image.fromarray(np.floor_divide(array,factor)+(255-256//factor))

class Picker:
    def __init__(self,options):
        self.gen = cycle(options)
        self.item = next(self.gen)
    def __call__(self):
        return self.item
    def next(self):
        self.item = next(self.gen)

ICON_SIZE = 50
class IconPicker(Picker):
    def __init__(self,parent_widget,left,top,choices,icons):
        super().__init__(choices)
        self.icon = QLabel("",parent_widget)
        self.icon.setGeometry(left,top,ICON_SIZE,ICON_SIZE)
        self.icon_gen = cycle(icons)
        self.next_icon()
        self.icon.show()
    def next(self):
        super().next()
        self.next_icon()
    def next_icon(self):
        qt_im = ImageQt(next(self.icon_gen))
        self.icon.setPixmap(QPixmap.fromImage(QImage(qt_im)))

class Partition:
    def __init__(self):
        self.domain = dict()
        self.represented = dict()
    def get_representative(self,item):
        if item not in self.domain:
            self.domain[item]=item
            self.represented[item] = [item]
            return item
        while self.domain[item]!=item:
            item = self.domain[item]
        return item
    def get_represented(self,item):
        if item in self.represented:
            return self.represented[item]
        else:
            if item in self.domain:
                return []
            else:
                self.domain[item]=item
                self.represented[item] = [item]
    def get_partition(self,item):
        return self.get_represented(self.get_representative(item))
    def join(self,item_1,item_2):
        representative_1 = self.get_representative(item_1)
        representative_2 = self.get_representative(item_2)
        self.domain[representative_2] = representative_1
        self.represented[representative_1] += self.represented.pop(representative_2)
    def list_non_singleton_parts(self):
        for group in self.represented.values():
            yield group
    def remove(self,item):
        if item in self.domain:
            prev_representative=self.get_representative(item)
            represented = self.represented[prev_representative]
            represented.remove(item)
            if len(represented)>0:
                new_representative = represented[0]
                for repr in represented:
                    self.domain[repr]=new_representative
                self.represented.pop(prev_representative)
                self.represented[new_representative]=represented
            else:
                self.represented.pop(prev_representative)
            self.domain.pop(item)

def convex_hull(points):
    '''
    Returns points on convex hull in CCW order according to Graham's scan algorithm. 
    By Tom Switzer <thomas.switzer@gmail.com>.
    '''
    TURN_LEFT, TURN_RIGHT, TURN_NONE = (1, -1, 0)

    def cmp(a, b):
        return int(a > b) - int(a < b)

    def turn(p, q, r):
        return cmp((q[0] - p[0])*(r[1] - p[1]) - (r[0] - p[0])*(q[1] - p[1]), 0)

    def _keep_left(hull, r):
        while len(hull) > 1 and turn(hull[-2], hull[-1], r) == TURN_RIGHT:
        #while len(hull) > 1 and turn(hull[-2], hull[-1], r) != TURN_LEFT:
            hull.pop()
        if not len(hull) or hull[-1] != r:
            hull.append(r)
        return hull

    points = sorted(points)
    l = reduce(_keep_left, points, [])
    u = reduce(_keep_left, reversed(points), [])
    return l.extend(u[i] for i in range(1, len(u) - 1)) or l

def minimal_spanning_tree(points,dist):
    #...on a complete graph (!), kruskal
    pairs = list(combinations(points,2))
    pairs.sort(key = lambda x : dist(*x))

    n = len(points)
    tree_counter=0
    partition = Partition()
    tree_pairs = []
    for item_1,item_2 in pairs:
        if partition.get_representative(item_1)!=partition.get_representative(item_2):
            partition.join(item_1,item_2)
            tree_pairs.append((item_1,item_2))
            tree_counter+=1
            if tree_counter >= n-1:
                break
    return tree_pairs
        
def dist(p1, p2):
    dx=p1[0]-p2[0]
    dy=p1[1]-p2[1]
    return sqrt(dx*dx+dy*dy)
