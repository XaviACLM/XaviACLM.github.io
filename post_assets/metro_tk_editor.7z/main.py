
import sys
import traceback

from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import Qt

from interface import MetroDrawingCanvas
from drawing import render
from constants import DATA_DIR, RENDER_DIR, ORIGINAL_MAP_DIR

def except_hook(cls, exception, traceback):
    sys.__excepthook__(cls, exception, traceback)
    sys.exit()
if __name__ == "__main__":
    sys.excepthook = except_hook

try:
    name = str(input(">"))
    command,fname = (lambda x,i:(x[:i],x[i+1:]))(name,name.index(" "))
    if command in ["draw","Draw"]:
        app = QApplication(sys.argv)
        act_app = MetroDrawingCanvas(fname)
        sys.exit(app.exec())
    elif command in ["render","Render"]:
        render("{}\\{}.mmf".format(DATA_DIR,fname),
               "{}\\{}.png".format(RENDER_DIR,fname))
    else:
        print("comando no recognogo")
except Exception as e:
    print(traceback.format_exc())
