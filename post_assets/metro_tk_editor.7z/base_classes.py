from util import Partition
from enum import Enum
import pickle as rick

"data classes w some input validation"

"no naming capability for stations/lines"

class Point:
    def __init__(self,x,y):
        self.x = x
        self.y = y
    def pos(self):
        return self.x,self.y
    
class ControlPoint(Point): pass
class Station(Point): pass

class Line:

    class Heading(Enum):
        START = 0
        END = 1
        
    def __init__(self,parent_map,*args,is_loop = False):
        self.color = (0,0,0,255)
        self.parent_map = parent_map
        self.stations = []
        self.is_loop = False
        for arg in args:
            self.add_station(arg, Line.Heading.END)
        self.is_loop = is_loop
    def add_station(self, station : Point, heading):# : Line.Heading):
        if self.is_loop: raise Exception("An attempt was made to append a station to a closed loop")
        if heading == Line.Heading.END:
            self.stations.append(station)
        elif heading == Line.Heading.START:
            self.stations = [station]+self.stations
        self.parent_map._register_station(station,self,heading)
    def has_terminal(self,station):
        return (not self.is_loop) and (station is self.stations[0]) or (station is self.stations[-1])
    def get_terminal(self,heading):
        return self.stations[0] if heading == Line.Heading.START else self.stations[-1]
    def get_heading_of(self,station):
        return None if self.is_loop else (\
               Line.Heading.START if station == self.stations[0] else (\
               Line.Heading.END if station == self.stations[-1] else None))
    def make_loop(self):
        self.is_loop = True
    def list_segments(self):
        for point in self.stations:
            yield point
        if self.is_loop:
            yield self.stations[0]
    def list_stations(self):
        for point in self.stations:
            if isinstance(point,Station):
                yield point
        
        

class MetroMap:
    def __init__(self):
        self.stations = []
        self.lines = []
        self.links = Partition()
        self.groups = []
        self.weak_groups = []

    def add_line(self,*args,is_loop = False):
        self.lines.append(Line(self,*args, is_loop = is_loop))
    def link(self,station_1,station_2):
        self.links.join(station_1,station_2)
    def _register_station(self,station,line,heading):
        self.stations.append(station)
    def add_group(self,group):
        self.groups.append(group)
    def add_weak_group(self,weak_group):
        self.weak_groups.append(weak_group)
    def list_links(self):
        for link in self.links.list_non_singleton_parts():
            yield link

    def get_line(self,station):
        for line in self.lines:
            if station in line.stations:
                return line

    def remove_station(self,station):
        self.stations.remove(station)
        line = self.get_line(station)
        if len(line.stations)<=1:
            line.stations.remove(station)
            self.lines.remove(line)
        elif line.has_terminal(station):
            line.stations.remove(station)
        elif line.is_loop:
            index = line.stations.index(station)
            line.is_loop = False
            line.stations = line.stations[index+1:]+line.stations[:index]
        else:
            index = line.stations.index(station)
            #line_left = Line(self,*line.stations[:index])
            #line_right = Line(self,*line.stations[index+1:])
            line_left = Line(self); line_left.stations.extend(line.stations[:index])
            line_right = Line(self); line_right.stations.extend(line.stations[index+1:])
            # not using add_line bc it re-adds the stations
            self.lines.remove(line)
            self.lines.append(line_left)
            self.lines.append(line_right)
        for group in self.groups:
            if station in group:
                group.remove(station)
        for weak_group in self.weak_groups:
            if station in weak_group:
                weak_group.remove(station)
        self.links.remove(station)

    def join_stations(self,station_1,station_2):
        if station_1 == station_2:
            raise Exception("An attempt was made to join a station to itself")
        line_1 = self.get_line(station_1)
        line_2 = self.get_line(station_2)
        if not (line_1.has_terminal(station_1) and line_2.has_terminal(station_2)):
            raise Exception("An attempt was made to extend a line from the middle")
        if line_1 == line_2:
            line_1.make_loop()
        else:
            if station_1==line_1.stations[0]:
                line_1.stations.reverse()
            if station_2==line_2.stations[-1]:
                line_2.stations.reverse()
            # choppy append to avoid re-adding, as before
            line_1.stations += line_2.stations
            self.lines.remove(line_2)

    def save(self,filename):
        with open(filename,"wb") as f:
            station_ids = {station:id for station,id in zip(self.stations,range(len(self.stations)))}
            stations = [(isinstance(station,Station),(float(station.x),float(station.y))) for station in self.stations]
            lines = [(line.is_loop,[station_ids[station] for station in line.stations]) for line in self.lines]
            groups = [[station_ids[station] for station in group] for group in self.groups]
            weak_groups = [[station_ids[station] for station in weak_group] for weak_group in self.weak_groups]
            links = [[station_ids[station] for station in link] for link in self.list_links()]
            colors = [line.color for line in self.lines]
            rick.dump((links,stations,lines,groups,weak_groups,colors),f)

    def load(self,filename):
        self.stations = []
        self.lines = []
        self.links = Partition()
        self.groups = []
        self.weak_groups = []
        try:
            with open(filename,"rb") as f:
                links,stations,lines,groups,weak_groups,colors = rick.load(f)
        except:
            with open(filename,"rb") as f:
                links,stations,lines,groups,weak_groups = rick.load(f)
                colors = [(0,0,0,255) for line in lines]
        stations = [Station(*pos) if is_visible else ControlPoint(*pos) for is_visible,pos in stations]
        for is_loop,line in lines:
            self.add_line(*[stations[i] for i in line],is_loop=is_loop)
        for color,line in zip(colors,self.lines):
            line.color = color
        for group in groups:
            self.add_group([stations[i] for i in group])
        for weak_group in weak_groups:
            self.add_weak_group([stations[i] for i in weak_group])
        for link in links:
            parent = stations[link[0]]
            for elem in link[1:]:
                self.link(parent,stations[elem])
            
            
            
        #line lookup in map vs line dict in map vs line reference in point
        #comes up here and in _register_station and remove_station
        #aswell as GraphicalMetroMap._register_station
        #(a dict lookup seems like the best option, huh? and it helps the _register thing make sense too)
        #it can also be expanded from the get_line
        
